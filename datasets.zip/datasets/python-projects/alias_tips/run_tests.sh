#!/bin/bash
set -e
python -m unittest test_alias_tips.py
