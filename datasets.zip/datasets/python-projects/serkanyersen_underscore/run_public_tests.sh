#!/bin/bash
set -e
python -m pytest public_tests
