# 数据集说明

本目录保存 repo-level code translation pipeline 的课程演示数据集。数据集按源项目语言组织：

```text
datasets/
  java-projects/       # Java 源项目，用于 Java -> Python
  python-projects/     # Python 源项目，用于 Python -> Java
```

每个项目都是一个可独立分析、规划、翻译和验证的源仓库。生成结果统一写到：

```text
results/<direction>/<project-name>/
  analysis/            # 源项目静态 AST、File Tree、LLM 语义分析
  plans/               # 目标项目总体规划、AST skeleton、空骨架项目
  translated/          # 生成后的目标项目
  logs/                # 进度日志、retrieval 日志、refine 日志
  validation/          # 编译/测试验证报告
```

## Java 源项目

### `java-projects/java-string-similarity`

源项目是 Java 字符串相似度算法库，目标是迁移为 Python 算法库。

包含：

- Maven 项目结构
- 多个独立算法类，例如 Levenshtein、Jaro-Winkler、NGram、Cosine、Jaccard
- 接口和抽象基类
- 单元测试与 public tests
- 纯算法逻辑，外部依赖较少

适合展示：

- Java 类和接口到 Python module/class/function 的结构规划
- AST/File Tree 分析
- 目标 Python 项目规划与 `python_project_sketeon.json`
- 逐文件翻译和测试验证

运行示例：

```bash
venv/bin/python translate_repo.py \
  --direction java-python \
  --source datasets/java-projects/java-string-similarity \
  --results-root results/java-python/java-string-similarity \
  --model gpt-4o \
  run
```

### `java-projects/chat-room`

Java -> Python 的 Web/服务端案例。源项目来自一对一聊天 Spring Boot WebSocket 项目，复杂度高于算法库。

包含：

- Spring Boot / Maven 项目
- WebSocket 聊天业务
- Controller / Service / Repository 风格代码
- 配置文件、Docker Compose、图片和说明文档
- 数据持久化相关接口

适合展示：

- Java Web 项目结构分析
- 服务端业务代码迁移规划
- 配置和资源文件在 repo-level 翻译中的处理

注意：

- 该项目比 `java-string-similarity` 更接近真实 Web 项目，但依赖和运行环境也更复杂。

运行示例：

```bash
venv/bin/python translate_repo.py \
  --direction java-python \
  --source datasets/java-projects/chat-room \
  --results-root results/java-python/chat-room \
  --model gpt-4o \
  run
```

## Python 源项目

### `python-projects/alias_tips`

Python -> Java 的最小稳定演示案例。源项目是一个命令别名推荐工具，目标是迁移为 Java/Maven 项目。

包含：

- 单核心模块 `alias_tips.py`
- 两个简单函数：`suggest_alias` 和 `is_alias_recommended`
- `unittest` 基础测试和 public tests
- 精确字符串匹配、空值/类型边界输入处理

适合展示：

- Python 纯函数到 Java class/static method 的迁移
- Python 项目语义分析
- Java 项目规划与 `java_project_sketeon.json`
- Maven 测试验证和 refine 闭环的稳定成功路径

注意：

- 该项目逻辑极小、无外部依赖、无文件/网络副作用，适合作为 Python -> Java 的首个演示案例。
- 已用 `gpt-4o`、`--refine-iterations 5` 连续验证 5 次，最终均通过 `mvn -q test`。

运行示例：

```bash
venv/bin/python translate_repo.py \
  --direction python-java \
  --source datasets/python-projects/alias_tips \
  --results-root results/python-java/alias_tips \
  --model gpt-4o \
  --refine-iterations 5 \
  run
```

### `python-projects/serkanyersen_underscore`

Python -> Java 的小型工具函数库案例。源项目是 Underscore 风格的 Python 工具函数集合。

包含：

- 单核心模块 `src/underscore.py`
- 列表工具函数：`chunk`、`compact`、`map_`
- 函数工具：`identity`、`once`
- 字典/集合工具：`is_empty`、`keys`、`pairs`
- 随机整数工具：`random`
- pytest 测试与 public tests

适合展示：

- Python 工具函数模块到 Java 工具类的迁移
- Python lambda/callback 到 Java `Function` 接口的映射
- Python truthy/falsy 和 Java 类型系统之间的差异
- public tests 对边界行为的补充验证

注意：

- 该项目比 `alias_tips` 稍复杂，但仍然是纯函数/工具逻辑，适合展示从简单案例过渡到多函数库案例。
- 目标目录中的测试脚本已改为直接使用 `python -m pytest`，避免依赖额外的 `coverage` 命令。

运行示例：

```bash
venv/bin/python translate_repo.py \
  --direction python-java \
  --source datasets/python-projects/serkanyersen_underscore \
  --results-root results/python-java/serkanyersen_underscore \
  --model gpt-4o \
  --refine-iterations 5 \
  run
```
